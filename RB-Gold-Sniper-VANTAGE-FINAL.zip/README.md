# RB Gold Sniper — Vantage MT5

App limpa para XAUUSD baseada no feed do MT5 Vantage.
- M5 principal; M15/H1 confirmação
- BUY/SELL/WAIT e score
- RSI, EMA20/50/200, ATR
- BOS, CHOCH e liquidity sweep
- Entry, SL, TP1, TP2
- TradingView OANDA:XAUUSD para visualização
- Sem IA
- Sem capital
- Sem execução automática de ordens

## Vercel
Criar a variável de ambiente `MT5_BRIDGE_KEY`.

## MT5
No EA `RB_Gold_Sniper_Bridge.mq5`, colocar a URL da produção em `ApiURL` e a mesma chave em `ApiKey`.
No MT5: Ferramentas > Opções > Expert Advisors > Permitir WebRequest e adicionar o domínio da Vercel.
