#property strict
#property version "1.00"
input string ApiURL="https://SEU-DOMINIO.vercel.app/api/mt5";
input string ApiKey="ALTERAR_CHAVE";
input string PreferredSymbol="XAUUSD";
input int BarsToSend=250;
input int SendEverySeconds=15;
string S="";
string FindSymbol(){string a[]={"XAUUSD","XAUUSDm","XAUUSD.a","XAUUSD#","GOLD","GOLDm"};for(int i=0;i<ArraySize(a);i++)if(SymbolSelect(a[i],true))return a[i];return "";}
string C(ENUM_TIMEFRAMES tf){MqlRates r[];int n=CopyRates(S,tf,0,BarsToSend,r);if(n<=0)return "[]";string j="[";for(int i=0;i<n;i++){if(i)j+=",";j+="{\"time\":"+IntegerToString((long)r[i].time)+",\"open\":"+DoubleToString(r[i].open,5)+",\"high\":"+DoubleToString(r[i].high,5)+",\"low\":"+DoubleToString(r[i].low,5)+",\"close\":"+DoubleToString(r[i].close,5)+",\"tick_volume\":"+IntegerToString((long)r[i].tick_volume)+",\"spread\":"+IntegerToString(r[i].spread)+"}";}return j+"]";}
void Send(){MqlTick t;if(!SymbolInfoTick(S,t))return;string b="{\"source\":\"VANTAGE_MT5\",\"symbol\":\""+S+"\",\"server_time\":"+IntegerToString((long)TimeCurrent())+",\"bid\":"+DoubleToString(t.bid,5)+",\"ask\":"+DoubleToString(t.ask,5)+",\"last\":"+DoubleToString(t.last,5)+",\"spread\":"+DoubleToString(t.ask-t.bid,5)+",\"digits\":"+IntegerToString((int)SymbolInfoInteger(S,SYMBOL_DIGITS))+",\"m5\":"+C(PERIOD_M5)+",\"m15\":"+C(PERIOD_M15)+",\"h1\":"+C(PERIOD_H1)+"}";char d[],r[];StringToCharArray(b,d,0,StringLen(b),CP_UTF8);string h="Content-Type: application/json\r\nX-RB-API-Key: "+ApiKey+"\r\n";string rh;int code=WebRequest("POST",ApiURL,h,10000,d,r,rh);Print("RB SNIPER HTTP=",code," ",CharArrayToString(r));}
int OnInit(){S=FindSymbol();if(S=="")return INIT_FAILED;EventSetTimer(MathMax(5,SendEverySeconds));Send();return INIT_SUCCEEDED;}
void OnTimer(){Send();}
void OnDeinit(const int reason){EventKillTimer();}
void OnTick(){}
