// api/mt5.js
// Ponte MT5 Vantage -> RB Gold Sniper.
// SOMENTE RECEÇÃO DE DADOS. NÃO EXISTE EXECUÇÃO DE ORDENS.

import { setLatestMarket } from "./analyze.js";

const MAX_BARS=250;
const MAX_AGE=180;
const MAX_BODY=2000000;

function out(res,status,data){
  res.status(status);
  res.setHeader("Content-Type","application/json");
  res.setHeader("Cache-Control","no-store");
  res.end(JSON.stringify(data));
}
function key(req){return req.headers["x-rb-api-key"]||""}
function bars(v,name){
  if(!Array.isArray(v)||!v.length)throw new Error(name+" sem candles");
  if(v.length>MAX_BARS)throw new Error(name+" excede "+MAX_BARS);
  return v.map((x,i)=>{
    const z={time:Number(x.time),open:Number(x.open),high:Number(x.high),low:Number(x.low),close:Number(x.close),
      tick_volume:Number(x.tick_volume)||0,spread:Number(x.spread)||0};
    if(![z.time,z.open,z.high,z.low,z.close].every(Number.isFinite))throw new Error(name+" candle "+i+" inválido");
    if(z.high<z.low||z.open<z.low||z.open>z.high||z.close<z.low||z.close>z.high)throw new Error(name+" candle "+i+" incoerente");
    return z;
  });
}
async function body(req){
  if(Number(req.headers["content-length"]||0)>MAX_BODY)throw new Error("Payload demasiado grande");
  return new Promise((resolve,reject)=>{
    let s="";
    req.setEncoding("utf8");
    req.on("data",c=>{s+=c;if(Buffer.byteLength(s)>MAX_BODY)reject(new Error("Payload demasiado grande"))});
    req.on("end",()=>resolve(s));req.on("error",reject);
  });
}
export default async function handler(req,res){
  if(req.method!=="POST")return out(res,405,{ok:false,error:"Usar POST"});
  const expected=process.env.MT5_BRIDGE_KEY||"";
  if(!expected)return out(res,503,{ok:false,error:"MT5_BRIDGE_KEY não configurada"});
  if(key(req)!==expected)return out(res,401,{ok:false,error:"Chave MT5 inválida"});
  let p;
  try{p=JSON.parse(await body(req))}catch(e){return out(res,400,{ok:false,error:"JSON inválido"})}
  try{
    if(p.source!=="VANTAGE_MT5")throw new Error("source inválido");
    const symbol=String(p.symbol||"");
    const ns=symbol.toUpperCase().replace(/[^A-Z0-9]/g,"");
    if(!ns.includes("XAUUSD")&&!ns.includes("GOLD"))throw new Error("Símbolo não é XAUUSD/GOLD");
    const market={
      symbol,price:(Number(p.bid)+Number(p.ask))/2,bid:Number(p.bid),ask:Number(p.ask),
      last:Number(p.last)||0,spread:Number(p.spread)||(Number(p.ask)-Number(p.bid)),
      digits:Number(p.digits)||2,server_time:Number(p.server_time)||0,
      m5:bars(p.m5,"M5"),m15:bars(p.m15,"M15"),h1:bars(p.h1,"H1")
    };
    if(!Number.isFinite(market.bid)||!Number.isFinite(market.ask)||market.bid<=0||market.ask<market.bid)throw new Error("Bid/Ask inválidos");
    const now=Math.floor(Date.now()/1000);
    if(market.server_time && Math.abs(now-market.server_time)>MAX_AGE)throw new Error("timestamp MT5 demasiado antigo");
    setLatestMarket(market);
    return out(res,200,{ok:true,bridge:"RB_GOLD_SNIPER",source:"VANTAGE_MT5",symbol, status:"LIVE",
      candles:{M5:market.m5.length,M15:market.m15.length,H1:market.h1.length},
      execution:{automatic_trading:false,orders_enabled:false}});
  }catch(e){return out(res,400,{ok:false,error:e.message})}
}