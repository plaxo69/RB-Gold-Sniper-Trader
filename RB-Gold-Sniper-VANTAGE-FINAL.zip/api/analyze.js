// api/analyze.js
// Analisa exclusivamente os últimos dados recebidos do MT5 Vantage.
// Não usa GC=F. Não executa ordens.

const MAX_AGE_SECONDS = 90;

let latest = null;
let receivedAt = 0;

function json(res,status,data){
  res.status(status);
  res.setHeader("Content-Type","application/json");
  res.setHeader("Cache-Control","no-store");
  res.end(JSON.stringify(data));
}
function ema(values,p){
  if(values.length<p)return null;
  let e=values.slice(0,p).reduce((a,b)=>a+b,0)/p;
  const k=2/(p+1);
  for(let i=p;i<values.length;i++)e=values[i]*k+e*(1-k);
  return e;
}
function rsi(values,p=14){
  if(values.length<p+1)return null;
  let g=0,l=0;
  for(let i=1;i<=p;i++){const d=values[i]-values[i-1];if(d>=0)g+=d;else l-=d}
  let ag=g/p,al=l/p;
  for(let i=p+1;i<values.length;i++){
    const d=values[i]-values[i-1];
    ag=((ag*(p-1))+(d>0?d:0))/p;
    al=((al*(p-1))+(d<0?-d:0))/p;
  }
  if(al===0)return 100;
  return 100-(100/(1+ag/al));
}
function atr(bars,p=14){
  if(bars.length<p+1)return null;
  const tr=[];
  for(let i=1;i<bars.length;i++){
    const b=bars[i], prev=bars[i-1];
    tr.push(Math.max(b.high-b.low,Math.abs(b.high-prev.close),Math.abs(b.low-prev.close)));
  }
  return tr.slice(-p).reduce((a,b)=>a+b,0)/p;
}
function trend(bars){
  const c=bars.map(x=>x.close), e20=ema(c,20),e50=ema(c,50),e200=ema(c,200);
  if(!e20||!e50||!e200)return "NEUTRO";
  if(e20>e50&&e50>e200)return "ALTA";
  if(e20<e50&&e50<e200)return "BAIXA";
  return "NEUTRO";
}
function structure(bars){
  const n=bars.length, recent=bars.slice(-20);
  const prev=bars.slice(-40,-20);
  if(!recent.length||!prev.length)return {bos:"N/D",choch:"N/D",liquidity:"N/D"};
  const rh=Math.max(...recent.map(x=>x.high)), rl=Math.min(...recent.map(x=>x.low));
  const ph=Math.max(...prev.map(x=>x.high)), pl=Math.min(...prev.map(x=>x.low));
  const last=bars[n-1];
  let bos="NÃO",choch="NÃO",liq="NÃO";
  if(last.close>ph)bos="BUY";
  else if(last.close<pl)bos="SELL";
  if(last.high>ph && last.close<ph)liq="SWEEP SELL";
  if(last.low<pl && last.close>pl)liq="SWEEP BUY";
  const tr=trend(bars);
  if(tr==="ALTA" && last.close<pl)choch="SELL";
  if(tr==="BAIXA" && last.close>ph)choch="BUY";
  return {bos,choch,liquidity:liq,rangeHigh:rh,rangeLow:rl};
}
function analyze(m){
  const m5=m.m5,m15=m.m15,h1=m.h1,c=m5.map(x=>x.close);
  const price=m.price, e20=ema(c,20),e50=ema(c,50),e200=ema(c,200),R=rsi(c),A=atr(m5);
  const t5=trend(m5),t15=trend(m15),th1=trend(h1),s=structure(m5);
  let buy=0,sell=0, reasons=[];
  if(t5==="ALTA")buy+=20;if(t5==="BAIXA")sell+=20;
  if(t15==="ALTA")buy+=15;if(t15==="BAIXA")sell+=15;
  if(th1==="ALTA")buy+=15;if(th1==="BAIXA")sell+=15;
  if(e20&&e50&&e200){
    if(price>e20&&e20>e50&&e50>e200)buy+=15;
    if(price<e20&&e20<e50&&e50<e200)sell+=15;
  }
  if(R!=null){if(R>=48&&R<=65)buy+=8;if(R>=35&&R<=52)sell+=8}
  if(s.bos==="BUY")buy+=12;if(s.bos==="SELL")sell+=12;
  if(s.choch==="BUY")buy+=8;if(s.choch==="SELL")sell+=8;
  if(s.liquidity==="SWEEP BUY")buy+=10;if(s.liquidity==="SWEEP SELL")sell+=10;
  const last=m5[m5.length-1], prev=m5[m5.length-2];
  if(last&&prev){
    const body=Math.abs(last.close-last.open), range=Math.max(last.high-last.low,1e-9);
    if(body/range>0.55 && last.close>last.open)buy+=5;
    if(body/range>0.55 && last.close<last.open)sell+=5;
  }
  let signal="WAIT",score=Math.max(buy,sell);
  // Regra sniper: exigir direção M5 e confirmação de pelo menos uma escala superior.
  if(buy>=70 && t5==="ALTA" && (t15==="ALTA"||th1==="ALTA") && buy>sell+10)signal="BUY";
  if(sell>=70 && t5==="BAIXA" && (t15==="BAIXA"||th1==="BAIXA") && sell>buy+10)signal="SELL";
  score=Math.min(100,Math.max(buy,sell));
  let entry=null,sl=null,tp1=null,tp2=null;
  if(A&&price){
    const risk=Math.max(A*1.25,price*0.0007);
    if(signal==="BUY"){entry=price;sl=price-risk;tp1=price+risk*1.5;tp2=price+risk*2.5}
    if(signal==="SELL"){entry=price;sl=price+risk;tp1=price-risk*1.5;tp2=price-risk*2.5}
  }
  let setup="SEM SETUP";
  if(s.liquidity!=="NÃO")setup="LIQUIDITY SWEEP";
  else if(s.bos!=="NÃO")setup="BREAKOUT/BOS";
  else if(signal!=="WAIT")setup="TREND + CONFIRMAÇÃO";
  return {
    signal,score,rsi:R,ema20:e20,ema50:e50,ema200:e200,atr:A,
    trendM5:t5,trendM15:t15,trendH1:th1,
    bos:s.bos,choch:s.choch,liquidity:s.liquidity,
    structure:signal==="WAIT"?"SEM CONFIRMAÇÃO":"CONFIRMADA",
    setup,entry,sl,tp1,tp2
  };
}

export default function handler(req,res){
  if(req.method!=="GET")return json(res,405,{error:"Método não permitido"});
  if(!latest){
    return json(res,200,{connected:false,market:null,analysis:{signal:"WAIT",score:0},message:"A aguardar MT5 Vantage."});
  }
  const age=(Date.now()-receivedAt)/1000;
  if(age>MAX_AGE_SECONDS){
    return json(res,200,{connected:false,market:null,analysis:{signal:"WAIT",score:0},message:"MT5 Vantage offline/dados antigos."});
  }
  return json(res,200,{connected:true,market:latest,analysis:analyze(latest),received_at:new Date(receivedAt).toISOString()});
}

// Função interna usada pelo endpoint de ingestão.
export function setLatestMarket(m){
  latest=m;
  receivedAt=Date.now();
}